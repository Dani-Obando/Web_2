<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['nombre_usuario'])) {
    header("Location: about.php");
    exit();
}

// Recuperar información del perfil desde la base de datos (ejemplo)
$nombre_usuario = $_SESSION['nombre_usuario'];
$informacion_adicional = "Información adicional del usuario";

// Información del gimnasio (nueva sección)
$historia_gimnasio = "Historia de ENERGym: Transformando Vidas a Través del Fitness
Hace más de una década, un grupo apasionado de entusiastas del fitness se unieron con un sueño común: crear un espacio que no solo transformara cuerpos, 
sino que también inspirara cambios de vida positivos. Así nació ENERGym, un lugar donde la energía, 
la salud y el bienestar convergen para forjar historias de éxito.";

$valores_gimnasio = "Valores que Nos Definen
En el corazón de ENERGym se encuentran nuestros valores fundamentales:
Compromiso con la Excelencia: Buscamos la excelencia en cada clase, entrenamiento y interacción.
Comunidad Inclusiva: Fomentamos un ambiente donde todos se sientan bienvenidos y apoyados.
Innovación Continua: Estamos comprometidos con la adopción de las últimas tendencias y tecnologías en el mundo del fitness.";

$mision_gimnasio = "Misión de ENERGym:
En ENERGym, nuestra misión es empoderar a individuos de todas las edades y niveles de condición física para que alcancen su máximo potencial de bienestar. 
Nos comprometemos a proporcionar un entorno inclusivo y motivador donde la excelencia en el fitness se combine con la comunidad y el apoyo. 
A través de programas innovadores, entrenadores dedicados y un enfoque holístico, aspiramos a ser el catalizador que impulsa la transformación positiva 
en la vida de nuestros miembros.";

$vision_gimnasio = "Visión de ENERGym:
Nuestra visión en ENERGym es ser reconocidos como el referente en el mundo del fitness, un lugar donde la salud, la vitalidad y la comunidad convergen de manera única. 
Buscamos liderar el camino en la creación de experiencias de fitness significativas, inspirando a las personas a adoptar un estilo de vida activo y equilibrado.
 A medida que avanzamos, visualizamos un futuro donde ENERGym es un faro de inspiración para aquellos que buscan un cambio positivo en sus vidas, trascendiendo 
los límites de lo que es posible a través del ejercicio y el bienestar integral.";
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido, <?php echo $nombre_usuario; ?> - ENERGym</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
    <style>
        /* ... Estilos existentes ... */
    </style>
</head>

<body class="d-flex flex-column">

    <nav class="navbar navbar-expand-lg navbar-light bg-purple">
        <!-- ... Contenido existente ... -->
    </nav>

    <!-- Sección de Historia del Gimnasio -->
    <section class="py-5">
        <div class="container text-center">
            <h2 class="text-purple">Historia de ENERGym</h2>
            <p class="lead"><?php echo $historia_gimnasio; ?></p>
            <hr class="my-4">
        </div>
    </section>

    <!-- Sección de Valores del Gimnasio -->
    <section class="py-5">
        <div class="container text-center">
            <h2 class="text-purple">Valores de ENERGym</h2>
            <p class="lead"><?php echo $valores_gimnasio; ?></p>
            <hr class="my-4">
        </div>
    </section>

    <!-- Sección de Misión del Gimnasio -->
    <section class="py-5">
        <div class="container text-center">
            <h2 class="text-purple">Misión de ENERGym</h2>
            <p class="lead"><?php echo $mision_gimnasio; ?></p>
            <hr class="my-4">
        </div>
    </section>

    <!-- Sección de Visión del Gimnasio -->
    <section class="py-5">
        <div class="container text-center">
            <h2 class="text-purple">Visión de ENERGym</h2>
            <p class="lead"><?php echo $vision_gimnasio; ?></p>
            <hr class="my-4">
        </div>
    </section>

    <!-- Sección de Bienvenida al Entrenador (código existente) -->
    <section class="py-5">
        <div class="container text-center">
            <h1 class="text-purple">¡Bienvenido Entrenador <?php echo $nombre_usuario; ?>!</h1>
            <?php if (!empty($informacion_adicional)) : ?>
                <p class="lead"><?php echo $informacion_adicional; ?></p>
            <?php endif; ?>
            <hr class="my-4">
        </div>
    </section>

    <!-- Pie de página (código existente) -->
    <footer class="mt-auto bg-purple text-white text-center py-3">
        <div class="container">
            <p>
                &copy; <?php echo date("Y"); ?> ENERGym - Todos los derechos reservados.
            </p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
